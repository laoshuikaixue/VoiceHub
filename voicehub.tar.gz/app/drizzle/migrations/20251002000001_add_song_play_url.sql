-- 添加歌曲播放地址字段
ALTER TABLE "Song" ADD COLUMN "playUrl" text;