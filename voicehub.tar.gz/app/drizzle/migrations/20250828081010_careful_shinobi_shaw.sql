ALTER TABLE "NotificationSettings" DROP CONSTRAINT "NotificationSettings_userId_unique";--> statement-breakpoint
ALTER TABLE "User" DROP CONSTRAINT "User_username_unique";